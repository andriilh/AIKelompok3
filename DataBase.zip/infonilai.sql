-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Jan 2019 pada 07.29
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `infonilai`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftarnilai`
--

CREATE TABLE `daftarnilai` (
  `nis` varchar(15) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `mtk` int(6) NOT NULL DEFAULT '0',
  `ipa` int(6) NOT NULL DEFAULT '0',
  `bind` int(6) NOT NULL DEFAULT '0',
  `jumlah` int(6) NOT NULL DEFAULT '0',
  `rata` int(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `daftarnilai`
--

INSERT INTO `daftarnilai` (`nis`, `nama`, `mtk`, `ipa`, `bind`, `jumlah`, `rata`) VALUES
('9898833323', 'Intan', 76, 89, 100, 265, 88),
('421363165', 'wawan', 23, 99, 99, 221, 73),
('9993565659', 'Andri', 89, 90, 91, 270, 90),
('1234567899', 'Andri Ilham', 87, 89, 88, 264, 88);

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftarsiswa`
--

CREATE TABLE `daftarsiswa` (
  `id` int(6) NOT NULL,
  `nis` varchar(15) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `ayah` varchar(50) NOT NULL,
  `ibu` varchar(50) NOT NULL,
  `telepon` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `daftarsiswa`
--

INSERT INTO `daftarsiswa` (`id`, `nis`, `nama`, `tgl_lahir`, `ayah`, `ibu`, `telepon`) VALUES
(9, '9993565659', 'Andri', '2006-07-21', 'Ahmad', 'Siti', '085314402108');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `daftarsiswa`
--
ALTER TABLE `daftarsiswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `daftarsiswa`
--
ALTER TABLE `daftarsiswa`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
